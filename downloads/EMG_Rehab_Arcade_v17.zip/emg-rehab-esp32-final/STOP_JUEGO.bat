@echo off
taskkill /IM emg-server.exe /F >nul 2>&1
echo EMG Rehab cerrado.
pause
