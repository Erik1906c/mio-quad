EMG REHAB - ESP32
=================

1. Carga primero esp32\EMG_Rehab_ESP32_Game.ino al ESP32 (electrodos desconectados).
2. El ESP32 crea la red WiFi: EMG-Rehab
   Contrasena: 12345678
3. Ejecuta INICIAR_JUEGO.bat.
4. Conecta la laptop a EMG-Rehab (12345678) y permanece conectado aunque Windows avise que no hay Internet.
5. Abre http://192.168.4.1/datos y confirma que el JSON incluya "signal".
6. Ejecuta INICIAR_JUEGO.bat y pulsa "Conectar ESP32". Si falla, lee el mensaje que aparece en pantalla.

SEGURIDAD
---------
Este prototipo académico no está verificado como equipo médicamente aislado. No conectes electrodos a una persona. Para depurar, usa el modo simulación o una señal de banco sin persona conectada.

CALIBRACION
-----------
- 3 s reposo
- 3 s contraccion comoda 1
- 4 s descanso
- 3 s contraccion comoda 2
- 4 s descanso
- 3 s contraccion comoda 3
- referencia = mediana de las 3 contracciones

JUEGO
-----
- >= 50%: dispara
- mientras siga >= 50%: otro disparo cada 500 ms
- < 30% durante 300 ms: termina/rearma la contraccion
- varios disparos NO cuentan como varias contracciones clinicas
