/**
 * SimulationSource.js
 * Fuente de señal simulada: convierte un slider de 0–600 mV en una señal final simulada en mV
 * y los emite a ~23 muestras/s, igual que la señal final enviada por el ESP32.
 * Pasa por exactamente la misma cadena (suavizado, calibración, detección).
 */
export class SimulationSource {
  constructor({ rateHz = 23, restAdc = 50, maxAdc = 600, noiseAdc = 2, onSignal, onStatus }) {
    Object.assign(this, { rateHz, restAdc, maxAdc, noiseAdc, onSignal, onStatus });
    this.level = restAdc;    // mV seleccionados en el slider
    this.current = restAdc;  // sigue al slider con inercia, como un músculo
    this.timer = null;
    this.isConnected = false;
  }

  setLevel(millivolts) {
    this.level = Math.min(this.maxAdc, Math.max(0, Number(millivolts) || 0));
  }

  connect() {
    if (this.isConnected) return;
    const dt = 1000 / this.rateHz;
    this.timer = setInterval(() => {
      const target = this.level;
      this.current += (target - this.current) * 0.15;
      const noise = (Math.random() * 2 - 1) * this.noiseAdc;
      this.onSignal?.(Math.max(0, Math.round(this.current + noise)));
    }, dt);
    this.isConnected = true;
    this.onStatus?.('connected');
  }

  disconnect() {
    clearInterval(this.timer);
    this.timer = null;
    if (this.isConnected) {
      this.isConnected = false;
      this.onStatus?.('disconnected');
    }
  }
}
