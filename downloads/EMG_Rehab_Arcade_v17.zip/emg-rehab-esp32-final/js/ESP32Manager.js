/**
 * ESP32Manager.js
 * Lee por WiFi la señal final procesada por el ESP32.
 *
 * El ESP32 crea la red "EMG-Rehab" y expone:
 *   GET http://192.168.4.1/datos
 *
 * Respuesta esperada:
 *   { signal: <mV sostenidos 250 ms>, raw: <mV instantáneos>, ... }
 *
 * Se usa HTTP polling para no requerir librerías WebSocket adicionales en el firmware.
 */
export class ESP32Manager {
  constructor({ baseUrl = 'http://192.168.4.1', rateHz = 23, requestTimeoutMs = 700, onSignal, onStatus }) {
    Object.assign(this, { baseUrl, rateHz, requestTimeoutMs, onSignal, onStatus });
    this.timer = null;
    this.isConnected = false;
    this.busy = false;
  }

  async _fetchJson() {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.requestTimeoutMs);
    try {
      const res = await fetch(`${this.baseUrl}/datos?_=${Date.now()}`, {
        method: 'GET',
        mode: 'cors',
        credentials: 'omit',
        cache: 'no-store',
        signal: controller.signal,
      });
      if (!res.ok) throw new Error(`ESP32 respondió HTTP ${res.status}`);
      try {
        return await res.json();
      } catch {
        throw new Error('192.168.4.1 respondió, pero /datos no entregó JSON válido.');
      }
    } catch (err) {
      if (err?.name === 'AbortError') {
        throw new Error('Se agotó el tiempo esperando al ESP32 en 192.168.4.1.');
      }
      if (err instanceof TypeError) {
        throw new Error('No hay respuesta del ESP32 o el navegador bloqueó la solicitud. Verifica la red EMG-Rehab y prueba http://192.168.4.1/datos.');
      }
      throw err;
    } finally {
      clearTimeout(timeout);
    }
  }

  async connect() {
    if (this.isConnected) return;
    const first = await this._fetchJson();
    if (!Number.isFinite(Number(first.signal))) {
      throw new Error('El ESP32 respondió, pero no envió una señal válida.');
    }
    this.isConnected = true;
    this.onStatus?.('connected');
    this._deliver(first);

    const period = Math.max(10, Math.round(1000 / this.rateHz));
    this.timer = setInterval(async () => {
      if (!this.isConnected || this.busy) return;
      this.busy = true;
      try {
        const data = await this._fetchJson();
        this._deliver(data);
      } catch (_) {
        // Un fallo aislado no desconecta inmediatamente. El timeout de señal de app.js
        // se encarga de avisar si dejan de llegar datos.
      } finally {
        this.busy = false;
      }
    }, period);
  }

  _deliver(data) {
    // Firmware nuevo: incluye todas las muestras tomadas desde la petición
    // anterior. Mapear millis() del ESP32 al reloj local conserva el tiempo
    // entre muestras, incluso cuando HTTP las entrega juntas.
    if (Array.isArray(data.samples) && data.samples.length > 0) {
      const now = performance.now();
      const espNow = Number(data.uptime);
      for (const sample of data.samples) {
        const value = Number(sample.signal);
        if (!Number.isFinite(value) || value < 0) continue;
        const sampleUptime = Number(sample.t);
        const age = Number.isFinite(espNow) && Number.isFinite(sampleUptime)
          ? ((espNow - sampleUptime) >>> 0)
          : 0;
        this.onSignal?.(value, now - age);
      }
      return;
    }

    // Si el lote todavía está vacío, usa la última lectura válida incluida en signal.
    const value = Number(data.signal);
    if (Number.isFinite(value) && value >= 0) this.onSignal?.(value, performance.now());
  }

  disconnect() {
    clearInterval(this.timer);
    this.timer = null;
    this.busy = false;
    if (this.isConnected) {
      this.isConnected = false;
      this.onStatus?.('disconnected');
    }
  }
}
