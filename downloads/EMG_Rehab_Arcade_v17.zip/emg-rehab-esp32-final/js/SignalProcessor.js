/**
 * SignalProcessor.js
 * La señal recibida del ESP32 ya representa la salida final promediada durante 250 ms.
 * Aquí solo se conserva una interfaz común y se convierte a % de activación.
 */
import { clamp } from './config.js?v=20261102-17';

export class SignalProcessor {
  constructor({ alpha = 1, minRange = 10 } = {}) {
    this.alpha = alpha;
    this.minRange = minRange;
    this.value = null;
    this.baseline = null;
    this.mvc = null; // "mvc" se conserva por compatibilidad; ahora es referencia cómoda segura.
  }

  smooth(raw) {
    this.value = this.value === null ? raw : this.value + this.alpha * (raw - this.value);
    return this.value;
  }

  resetFilter() {
    this.value = null;
  }

  setCalibration(baseline, mvc) {
    if (!Number.isFinite(baseline) || !Number.isFinite(mvc) || mvc - baseline < this.minRange) {
      throw new Error('Calibración inválida: la referencia quedó demasiado cerca del reposo.');
    }
    this.baseline = baseline;
    this.mvc = mvc;
  }

  clearCalibration() {
    this.baseline = null;
    this.mvc = null;
  }

  get isCalibrated() {
    return this.baseline !== null && this.mvc !== null;
  }

  toPercent(signal) {
    if (!this.isCalibrated) return 0;
    const range = this.mvc - this.baseline;
    if (range < this.minRange) return 0;
    return clamp(((signal - this.baseline) / range) * 100, 0, 100);
  }
}
