/**
 * app.js — ESP32 + WiFi
 *
 * Flujo real:
 *   ESP32 GPIO35 (salida final) -> promedio sostenido 250 ms -> HTTP WiFi
 *   -> onSignal(mV) -> calibración segura / % activación
 *   -> detector de contracción -> disparos -> juego.
 */
import { CONFIG } from './config.js?v=20261102-17';
import { ESP32Manager } from './ESP32Manager.js?v=20261102-17';
import { SimulationSource } from './SimulationSource.js?v=20261102-17';
import { SignalProcessor } from './SignalProcessor.js?v=20261102-17';
import { CalibrationManager } from './CalibrationManager.js?v=20261102-17';
import { RepDetector } from './RepDetector.js?v=20261102-17';
import { GameManager } from './GameManager.js?v=20261102-17';
import { PatientDatabase } from './PatientDatabase.js?v=20261102-17';
import { UIManager } from './UIManager.js?v=20261102-17';

const ui = new UIManager();
const db = new PatientDatabase();
const processor = new SignalProcessor({ alpha: CONFIG.smoothing.alpha, minRange: CONFIG.calibration.minRange });
const repDetector = new RepDetector(CONFIG.rep);
const game = new GameManager({ hpPerTargetRep: CONFIG.game.hpPerTargetRep });
const calibration = new CalibrationManager(CONFIG.calibration, {
  onComplete: onCalibrationComplete,
  onError: onCalibrationError,
});

const app = {
  screen: 'home',
  mode: 'idle',
  pending: null,
  calibrationResult: null,
  selectedPatientId: null,
  progressPatientId: null,
  last: { raw: 0, smooth: 0, percent: 0, t: 0 },
  samplesThisSecond: 0,
  rate: 0,
  attackQueue: Promise.resolve(),
};

// =====================================================================
// Entrada común de señal
// =====================================================================
function onSignal(raw, sampleTime = performance.now()) {
  const t = sampleTime;
  const smooth = processor.smooth(raw);
  const percent = processor.toPercent(smooth);
  app.last = { raw, smooth, percent, t };
  app.samplesThisSecond++;

  if (calibration.isRunning) calibration.addSample(smooth, t);

  if (app.mode === 'playing' && game.isActive) {
    const event = repDetector.update(percent, smooth, t);
    if (event?.shot) handleShot(event.shot);
    if (event?.rep) handleRep(event.rep);
  }
}

// =====================================================================
// Fuentes: ESP32 WiFi y simulación
// =====================================================================
const hardware = new ESP32Manager({
  ...CONFIG.esp32,
  onSignal,
  onStatus: (s) => onSourceStatus('hardware', s),
});

const simulation = new SimulationSource({
  ...CONFIG.simulation,
  onSignal,
  onStatus: (s) => onSourceStatus('sim', s),
});

let activeSource = null;

function onSourceStatus(kind, status) {
  if (status === 'connected') {
    activeSource = kind;
    processor.resetFilter();
    app.last.t = performance.now();
  } else if (status === 'disconnected' && activeSource === kind) {
    activeSource = null;
    if (calibration.isRunning || app.mode === 'playing') {
      ui.toast('Se perdió la señal. Revisa la red EMG-Rehab y vuelve a conectar.', 6000);
    }
  }
  refreshDeviceUI();
}

function isStale() {
  return !!activeSource && performance.now() - app.last.t > CONFIG.signalTimeoutMs;
}

function refreshDeviceUI() {
  ui.setDevice({
    source: activeSource,
    serialConnected: hardware.isConnected,
    stale: isStale(),
    rate: app.rate,
  });
}

setInterval(() => {
  app.rate = app.samplesThisSecond;
  app.samplesThisSecond = 0;
  refreshDeviceUI();
}, 1000);

ui.el['btn-connect'].addEventListener('click', async () => {
  if (simulation.isConnected) {
    simulation.disconnect();
    ui.el['sim-toggle'].checked = false;
    ui.toggleSimPanel(false);
  }
  try {
    await hardware.connect();
    ui.toast('ESP32 conectado. Señal recibida por WiFi.', 3000);
  } catch (err) {
    ui.toast(`Conexión fallida: ${err?.message || 'error desconocido'}`, 9000);
  }
  refreshDeviceUI();
});

ui.el['btn-disconnect'].addEventListener('click', () => hardware.disconnect());

ui.el['sim-toggle'].addEventListener('change', async (e) => {
  if (e.target.checked) {
    hardware.disconnect();
    ui.setSimValue(CONFIG.simulation.restAdc);
    simulation.setLevel(CONFIG.simulation.restAdc);
    simulation.connect();
  } else {
    simulation.disconnect();
  }
  ui.toggleSimPanel(e.target.checked);
  refreshDeviceUI();
});

const slider = ui.el['sim-slider'];
slider.addEventListener('input', () => {
  simulation.setLevel(slider.value);
  ui.setSimValue(slider.value);
});
// En modo prueba, el nivel elegido se mantiene al soltar el control.
// Para relajar la señal, mueve el deslizador al nivel de reposo calibrado.

// =====================================================================
// Navegación
// =====================================================================
function go(screen) {
  app.screen = screen;
  ui.showScreen(screen);
}

// =====================================================================
// Inicio / pacientes
// =====================================================================
async function refreshPatients(selectId = app.selectedPatientId) {
  const patients = await db.getPatients();
  const exists = patients.some(p => p.id === selectId);
  ui.renderPatientOptions(patients, exists ? selectId : null);
  await onPatientSelected(exists ? selectId : null);
}

async function onPatientSelected(id) {
  app.selectedPatientId = id;
  if (id) {
    const patient = await db.getPatient(id);
    const sessions = await db.getSessions(id);
    ui.setHomeForm({ name: patient.name, sessionNumber: await db.nextSessionNumber(id), existing: true });
    ui.renderHistory(sessions);
  } else {
    ui.setHomeForm({ name: '', sessionNumber: 1, existing: false });
    ui.renderHistory(null);
  }
}

ui.el['patient-select'].addEventListener('change', (e) => onPatientSelected(Number(e.target.value) || null));
ui.el['target-reps'].addEventListener('input', (e) => ui.updateHpPreview(e.target.value));
ui.el['btn-progress'].addEventListener('click', () => {
  if (app.selectedPatientId) openProgress(app.selectedPatientId);
});

ui.el['btn-start'].addEventListener('click', async () => {
  const f = ui.readHomeForm();
  if (!f.patientId && !f.name) return ui.setHomeError('Escribe el nombre del paciente.');
  if (!Number.isInteger(f.sessionNumber) || f.sessionNumber < 1) return ui.setHomeError('El número de sesión debe ser un entero mayor que 0.');
  if (!Number.isInteger(f.targetReps) || f.targetReps < 1 || f.targetReps > 100) {
    return ui.setHomeError('Las contracciones objetivo deben ser un entero entre 1 y 100.');
  }
  if (!activeSource || isStale()) return ui.setHomeError('Conecta el ESP32 por WiFi o activa el modo simulación antes de iniciar.');

  const patient = f.patientId ? await db.getPatient(f.patientId) : await db.getOrCreatePatient(f.name);
  app.selectedPatientId = patient.id;
  app.pending = { patient, sessionNumber: f.sessionNumber, targetReps: f.targetReps };
  app.calibrationResult = null;
  calibration.reset();
  processor.clearCalibration();
  ui.resetCalibration(patient.name, f.sessionNumber);
  ui.updateCalibration(calibration.status(performance.now()), app.last.smooth);
  go('calibration');
});

// =====================================================================
// Calibración segura: reposo + 3 contracciones cómodas
// =====================================================================
ui.el['btn-cal-start'].addEventListener('click', () => {
  if (!activeSource || isStale()) {
    ui.showCalibrationError('No hay señal estable. Revisa la conexión WiFi con el ESP32.');
    return;
  }
  processor.clearCalibration();
  app.calibrationResult = null;
  ui.setCalibrationRunning(true);
  calibration.start(performance.now());
});

ui.el['btn-cal-back'].addEventListener('click', async () => {
  calibration.reset();
  go('home');
  await refreshPatients();
});

ui.el['btn-cal-continue'].addEventListener('click', () => {
  const { patient, sessionNumber, targetReps } = app.pending;
  const { baseline, mvc } = app.calibrationResult;
  const s = game.startSession({ patient, sessionNumber, targetReps, baseline, mvc });
  repDetector.reset();
  app.attackQueue = Promise.resolve();
  ui.setupGame({ patientName: patient.name, sessionNumber, targetReps, mvc, maxHP: s.monsterMaxHP });
  app.mode = 'playing';
  go('game');
});

function onCalibrationComplete({ baseline, mvc, peaks }) {
  try {
    processor.setCalibration(baseline, mvc);
    app.calibrationResult = { baseline, mvc, peaks };
    ui.showCalibrationResult({ baseline, mvc, peaks });
  } catch (err) {
    onCalibrationError(err.message);
  }
}

function onCalibrationError(msg) {
  ui.showCalibrationError(msg);
}

// =====================================================================
// Juego: disparos durante una contracción sostenida
// =====================================================================
function handleShot(shot) {
  const result = game.registerShot(shot);
  if (!result) return;
  app.attackQueue = app.attackQueue.then(() => ui.playShot(result));
}

function handleRep(rep) {
  const result = game.registerRep(rep);
  if (!result) return;

  ui.completeRep(result.rep, game.session.targetReps);

  if (result.finished) {
    app.mode = 'finishing';
    const record = game.toRecord();
    const summary = game.summary();

    app.attackQueue = app.attackQueue.then(async () => {
      await new Promise(r => setTimeout(r, 700));
      try {
        await db.addSession(record);
      } catch (err) {
        ui.toast(`No se pudo guardar la sesión: ${err.message}`, 6000);
      }
      game.endSession();
      app.mode = 'idle';
      app.selectedPatientId = record.patientId;
      ui.showSummary(summary, record);
      go('summary');
    });
  }
}

ui.el['btn-game-cancel'].addEventListener('click', async () => {
  if (!confirm('¿Cancelar la sesión? Las contracciones realizadas no se guardarán.')) return;
  game.endSession();
  app.mode = 'idle';
  go('home');
  await refreshPatients();
});

// =====================================================================
// Resumen y progreso
// =====================================================================
ui.el['btn-sum-home'].addEventListener('click', async () => {
  go('home');
  await refreshPatients();
});
ui.el['btn-sum-progress'].addEventListener('click', () => openProgress(app.selectedPatientId));

async function openProgress(patientId) {
  const patient = await db.getPatient(patientId);
  if (!patient) return;
  app.progressPatientId = patientId;
  ui.showProgress(patient, await db.getSessions(patientId));
  go('progress');
}

ui.el['btn-prog-back'].addEventListener('click', async () => {
  go('home');
  await refreshPatients();
});

// =====================================================================
// Exportar / importar
// =====================================================================
const stamp = () => new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
const slug = (s) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9]+/g, '_').toLowerCase();

async function exportCSV(patientId = null) {
  const csv = await db.exportCSV(patientId);
  const name = patientId ? slug((await db.getPatient(patientId)).name) : 'todos';
  ui.download(`semg_${name}_${stamp()}.csv`, '\uFEFF' + csv, 'text/csv;charset=utf-8');
}

async function exportJSON(patientId = null) {
  const data = await db.exportJSON(patientId);
  const name = patientId ? slug((await db.getPatient(patientId)).name) : 'todos';
  ui.download(`semg_${name}_${stamp()}.json`, JSON.stringify(data, null, 2), 'application/json');
}

ui.el['btn-export-csv'].addEventListener('click', () => exportCSV());
ui.el['btn-export-json'].addEventListener('click', () => exportJSON());
ui.el['btn-prog-csv'].addEventListener('click', () => exportCSV(app.progressPatientId));
ui.el['btn-prog-json'].addEventListener('click', () => exportJSON(app.progressPatientId));

ui.el['btn-import-json'].addEventListener('click', () => ui.el['import-file'].click());
ui.el['import-file'].addEventListener('change', async (e) => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  try {
    const data = JSON.parse(await file.text());
    const { added, skipped } = await db.importJSON(data);
    ui.toast(`Importación completa: ${added} sesiones nuevas, ${skipped} omitidas.`, 6000);
    await refreshPatients();
  } catch (err) {
    ui.toast(`No se pudo importar: ${err.message}`, 6000);
  }
});

// =====================================================================
// Interfaz 60 fps
// =====================================================================
function frame() {
  const t = performance.now();

  if (calibration.isRunning) {
    const status = calibration.tick(t);
    ui.updateCalibration(status, app.last.smooth);
  } else if (app.screen === 'calibration') {
    ui.updateCalibration(calibration.status(t), app.last.smooth);
  }

  if (app.screen === 'game' && app.mode === 'playing') {
    const percent = isStale() || !activeSource ? 0 : app.last.percent;
    ui.updateLive(percent, repDetector.state, repDetector.peakPercent);
  }

  requestAnimationFrame(frame);
}

// =====================================================================
// Inicio
// =====================================================================
(async function init() {
  // La versión ESP32 no depende de Web Serial.
  ui.setSerialSupported(true);
  ui.updateHpPreview(ui.el['target-reps'].value);
  try {
    await db.open();
    await refreshPatients(null);
  } catch (err) {
    ui.toast(`No se pudo abrir la base de datos local: ${err.message}`, 8000);
  }
  refreshDeviceUI();
  go('home');
  requestAnimationFrame(frame);
})();
