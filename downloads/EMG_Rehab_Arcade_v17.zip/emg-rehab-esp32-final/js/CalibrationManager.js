/**
 * CalibrationManager.js
 * Calibración segura:
 *   1) Reposo 3 s
 *   2) Contracción cómoda 1, 3 s
 *   3) Descanso 4 s
 *   4) Contracción cómoda 2, 3 s
 *   5) Descanso 4 s
 *   6) Contracción cómoda 3, 3 s
 *
 * La señal que llega desde el ESP32 ya es un promedio móvil de 250 ms.
 * Para cada contracción se toma el mayor valor sostenido y la referencia final
 * es la MEDIANA de las tres contracciones, evitando que un pico atípico domine.
 */
export const CalPhase = {
  IDLE: 'idle',
  REST: 'rest',
  CONTRACTION_1: 'contraction1',
  BREAK_1: 'break1',
  CONTRACTION_2: 'contraction2',
  BREAK_2: 'break2',
  CONTRACTION_3: 'contraction3',
  DONE: 'done',
  ERROR: 'error',
};

export class CalibrationManager {
  constructor(cfg, { onComplete, onError } = {}) {
    this.cfg = cfg;
    this.onComplete = onComplete;
    this.onError = onError;
    this.reset();
  }

  reset() {
    this.phase = CalPhase.IDLE;
    this.phaseStart = 0;
    this.restSamples = [];
    this.contractionSamples = [[], [], []];
    this.baseline = null;
    this.mvc = null;
    this.peaks = [null, null, null];
    this.error = '';
  }

  start(t) {
    this.reset();
    this._enter(CalPhase.REST, t);
  }

  get isRunning() {
    return [
      CalPhase.REST,
      CalPhase.CONTRACTION_1,
      CalPhase.BREAK_1,
      CalPhase.CONTRACTION_2,
      CalPhase.BREAK_2,
      CalPhase.CONTRACTION_3,
    ].includes(this.phase);
  }

  addSample(value, t) {
    if (!Number.isFinite(value)) return;
    if (this.phase === CalPhase.REST && t - this.phaseStart >= this.cfg.restDiscardMs) {
      this.restSamples.push(value);
    } else if (this.phase === CalPhase.CONTRACTION_1) {
      this.contractionSamples[0].push(value);
    } else if (this.phase === CalPhase.CONTRACTION_2) {
      this.contractionSamples[1].push(value);
    } else if (this.phase === CalPhase.CONTRACTION_3) {
      this.contractionSamples[2].push(value);
    }
  }

  tick(t) {
    const elapsed = t - this.phaseStart;

    if (this.phase === CalPhase.REST && elapsed >= this.cfg.restMs) {
      if (this.restSamples.length < 10) return this._fail('No se recibió señal suficiente durante el reposo.');
      this.baseline = median(this.restSamples);
      this._enter(CalPhase.CONTRACTION_1, t);
    }

    else if (this.phase === CalPhase.CONTRACTION_1 && elapsed >= this.cfg.contractionMs) {
      if (!this._finishContraction(0)) return this.status(t);
      this._enter(CalPhase.BREAK_1, t);
    }

    else if (this.phase === CalPhase.BREAK_1 && elapsed >= this.cfg.breakMs) {
      this._enter(CalPhase.CONTRACTION_2, t);
    }

    else if (this.phase === CalPhase.CONTRACTION_2 && elapsed >= this.cfg.contractionMs) {
      if (!this._finishContraction(1)) return this.status(t);
      this._enter(CalPhase.BREAK_2, t);
    }

    else if (this.phase === CalPhase.BREAK_2 && elapsed >= this.cfg.breakMs) {
      this._enter(CalPhase.CONTRACTION_3, t);
    }

    else if (this.phase === CalPhase.CONTRACTION_3 && elapsed >= this.cfg.contractionMs) {
      if (!this._finishContraction(2)) return this.status(t);
      this.mvc = median(this.peaks);
      if (this.mvc - this.baseline < this.cfg.minRange) {
        return this._fail('La referencia quedó demasiado cerca del reposo. Revisa electrodos y repite con contracciones cómodas un poco más claras.');
      }
      this.phase = CalPhase.DONE;
      this.onComplete?.({ baseline: this.baseline, mvc: this.mvc, peaks: [...this.peaks] });
    }

    return this.status(t);
  }

  status(t) {
    const elapsed = t - this.phaseStart;
    const duration = this._durationFor(this.phase);
    const progress = duration ? Math.min(1, elapsed / duration) : this.phase === CalPhase.DONE ? 1 : 0;
    const secondsLeft = duration ? Math.max(0, Math.ceil((duration - elapsed) / 1000)) : 0;

    return {
      phase: this.phase,
      progress,
      secondsLeft,
      baseline: this.baseline,
      mvc: this.mvc,
      peaks: [...this.peaks],
      activeStep: this._activeStep(),
      instruction: this._instruction(),
      error: this.error,
    };
  }

  _finishContraction(index) {
    const arr = this.contractionSamples[index];
    if (arr.length < 10) {
      this._fail(`No se recibió señal suficiente durante la contracción ${index + 1}.`);
      return false;
    }
    this.peaks[index] = Math.max(...arr);
    return true;
  }

  _durationFor(phase) {
    if (phase === CalPhase.REST) return this.cfg.restMs;
    if ([CalPhase.CONTRACTION_1, CalPhase.CONTRACTION_2, CalPhase.CONTRACTION_3].includes(phase)) return this.cfg.contractionMs;
    if ([CalPhase.BREAK_1, CalPhase.BREAK_2].includes(phase)) return this.cfg.breakMs;
    return 0;
  }

  _activeStep() {
    if (this.phase === CalPhase.REST) return 0;
    if ([CalPhase.CONTRACTION_1, CalPhase.BREAK_1].includes(this.phase)) return 1;
    if ([CalPhase.CONTRACTION_2, CalPhase.BREAK_2].includes(this.phase)) return 2;
    if (this.phase === CalPhase.CONTRACTION_3) return 3;
    if (this.phase === CalPhase.DONE) return 4;
    return -1;
  }

  _instruction() {
    switch (this.phase) {
      case CalPhase.IDLE: return 'Coloca al paciente en posición y pulsa «Iniciar calibración».';
      case CalPhase.REST: return 'Relaja completamente el cuádriceps.';
      case CalPhase.CONTRACTION_1: return 'Contracción 1: fuerte pero cómoda, controlada y sin dolor.';
      case CalPhase.BREAK_1: return 'Descansa y relaja la pierna antes de la segunda contracción.';
      case CalPhase.CONTRACTION_2: return 'Contracción 2: fuerte pero cómoda, controlada y sin dolor.';
      case CalPhase.BREAK_2: return 'Descansa y relaja la pierna antes de la tercera contracción.';
      case CalPhase.CONTRACTION_3: return 'Contracción 3: fuerte pero cómoda, controlada y sin dolor.';
      case CalPhase.DONE: return 'Calibración completada. La referencia es la mediana de las tres contracciones.';
      case CalPhase.ERROR: return 'La calibración no se completó.';
      default: return '';
    }
  }

  _enter(phase, t) {
    this.phase = phase;
    this.phaseStart = t;
  }

  _fail(msg) {
    this.phase = CalPhase.ERROR;
    this.error = msg;
    this.onError?.(msg);
    return this.status(performance.now());
  }
}

function median(arr) {
  const s = [...arr].filter(Number.isFinite).sort((a, b) => a - b);
  if (!s.length) return NaN;
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}
