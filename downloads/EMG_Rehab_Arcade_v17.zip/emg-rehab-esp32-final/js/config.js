/**
 * config.js
 * Constantes ajustables del sistema ESP32 + sEMG.
 */
export const CONFIG = {
  // --- Comunicación ESP32 ---
  esp32: {
    baseUrl: 'http://192.168.4.1',
    rateHz: 23,
    requestTimeoutMs: 3000,
  },

  signalTimeoutMs: 1200,

  // La señal que manda el ESP32 ya es un promedio móvil de 250 ms.
  // alpha=1 evita agregar retraso adicional en la app.
  smoothing: {
    alpha: 1.0,
  },

  // --- Calibración segura ---
  calibration: {
    restMs: 3000,
    restDiscardMs: 500,
    contractionMs: 3000,
    breakMs: 4000,
    minRange: 10, // mV mínimos entre reposo y referencia
  },

  // --- Detección de contracciones y disparos ---
  rep: {
    startPercent: 50,      // umbral de activación
    activationConfirmMs: 130, // debe superar el umbral este tiempo para el primer disparo
    endPercent: 40,        // rearme cuando baja de 40 %
    relaxHoldMs: 300,      // debe permanecer relajado este tiempo para cerrar la contracción
    minRepMs: 400,
    cooldownMs: 250,
    shotIntervalMs: 1000,   // mientras se mantenga > 50 %, nuevo disparo cada 1000 ms
  },

  // --- Juego ---
  game: {
    hpPerTargetRep: 100,         // vida base del monstruo por repetición objetivo
    shotDamageScale: 1.0,        // cada golpe quita puntos según el porcentaje de activación
    minShotDamage: 5,
    attackDurationMs: 420,
  },

  attackColors: [
    { min: 90, color: '#7B2CBF', name: 'morado' },
    { min: 75, color: '#F07B1D', name: 'naranja' },
    { min: 50, color: '#E8B500', name: 'amarillo' },
    { min: 25, color: '#2F7DE1', name: 'azul' },
    { min: 0,  color: '#8A94A3', name: 'gris' },
  ],

  // --- Simulación en mV, aproximada a lo observado físicamente ---
  simulation: {
    rateHz: 23,
    restAdc: 50,
    maxAdc: 600,
    noiseAdc: 2,
  },
};

export function attackColorFor(percent) {
  return CONFIG.attackColors.find(c => percent >= c.min).color;
}

export const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
