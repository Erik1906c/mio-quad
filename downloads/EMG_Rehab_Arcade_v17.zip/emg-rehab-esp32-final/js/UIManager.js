/**
 * UIManager.js
 * Única capa que toca el DOM. No contiene reglas del juego ni sabe de dónde viene la señal:
 * recibe datos ya calculados y los muestra.
 */
import { CONFIG, attackColorFor } from './config.js?v=20261102-17';
import { CalPhase } from './CalibrationManager.js?v=20261102-17';
import { RepState } from './RepDetector.js?v=20261102-17';

const $ = (id) => document.getElementById(id);

export const escapeHtml = (s) => String(s ?? '').replace(/[&<>"']/g, c => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const fmtDate = (iso) => new Date(iso).toLocaleString('es-MX', { dateStyle: 'medium', timeStyle: 'short' });
const fmt1 = (n) => (Number.isFinite(n) ? (Math.round(n * 10) / 10).toLocaleString('es-MX') : '—');
const fmtSignal = (mv) => (Number.isFinite(Number(mv)) ? `${Math.round(Number(mv))} mV` : '—');
const legacyAdcToMv = (adc) => (Number(adc) * 5.0 / 16383) * 1000;
const storedToMv = (value, unit) => unit === 'mV' ? Number(value) : legacyAdcToMv(value);
const fmtStoredSignal = (value, unit) => fmtSignal(storedToMv(value, unit));
const CAL_METER_MIN_MV = 50;
const CAL_METER_MAX_MV = 400;
const calMeterPercent = (mv) => Math.min(100, Math.max(0, ((mv - CAL_METER_MIN_MV) / (CAL_METER_MAX_MV - CAL_METER_MIN_MV)) * 100));
const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const REP_STATE_TEXT = {
  [RepState.REST]: 'En reposo',
  [RepState.CONTRACTING]: 'Contrayendo / disparando',
  [RepState.RETURNING]: 'Relajando',
};

export class UIManager {
  constructor() {
    this.el = new Proxy({}, { get: (_, id) => $(id) });
    this.signalMinV = CAL_METER_MIN_MV;
    this.signalMaxV = CAL_METER_MAX_MV;
    this.toastTimer = null;
    this._placeThresholdMarks();
  }

  // ------------------------------------------------------------------ general
  showScreen(name) {
    for (const s of ['home', 'calibration', 'game', 'summary', 'progress']) {
      $(`screen-${s}`).hidden = s !== name;
    }
    window.scrollTo({ top: 0 });
  }

  toast(msg, ms = 3500) {
    const t = this.el.toast;
    t.textContent = msg;
    t.hidden = false;
    clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => { t.hidden = true; }, ms);
  }

  download(filename, text, mime) {
    const url = URL.createObjectURL(new Blob([text], { type: mime }));
    const a = Object.assign(document.createElement('a'), { href: url, download: filename });
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  // ------------------------------------------------------------------ conexión
  setSerialSupported(ok) {
    this.el['serial-warning'].hidden = ok;
    this.el['btn-connect'].disabled = !ok;
  }

  setDevice({ source, serialConnected, stale, rate }) {
    const st = this.el['device-status'];
    let text = 'ESP32 desconectado', cls = 'status--off';
    if (source === 'hardware') { text = stale ? 'ESP32 conectado, sin datos' : 'ESP32 conectado por WiFi'; cls = stale ? 'status--warn' : 'status--on'; }
    if (source === 'sim') { text = 'Simulación activa'; cls = 'status--sim'; }
    st.textContent = text;
    st.className = `status ${cls}`;
    this.el['device-rate'].textContent = source && !stale ? `${rate} muestras/s` : '';
    this.el['btn-connect'].hidden = serialConnected;
    this.el['btn-disconnect'].hidden = !serialConnected;
  }

  toggleSimPanel(show) {
    this.el['sim-panel'].hidden = !show;
  }

  setSimValue(v) {
    this.el['sim-slider'].value = v;
    this.el['sim-value'].textContent = `${v} mV`;
  }

  // ------------------------------------------------------------------ inicio
  renderPatientOptions(patients, selectedId) {
    const sel = this.el['patient-select'];
    sel.innerHTML = '<option value="">Crear paciente nuevo</option>' +
      patients.map(p => `<option value="${p.id}">${escapeHtml(p.name)}</option>`).join('');
    sel.value = selectedId ? String(selectedId) : '';
  }

  readHomeForm() {
    return {
      patientId: Number(this.el['patient-select'].value) || null,
      name: this.el['patient-name'].value.trim(),
      sessionNumber: Number(this.el['session-number'].value),
      targetReps: Number(this.el['target-reps'].value),
    };
  }

  setHomeForm({ name, sessionNumber, existing }) {
    const n = this.el['patient-name'];
    n.value = name;
    n.readOnly = existing;
    this.el['session-number'].value = sessionNumber;
    this.el['btn-progress'].disabled = !existing;
    this.setHomeError('');
  }

  updateHpPreview(reps) {
    const r = Number(reps);
    this.el['hp-preview'].textContent = Number.isInteger(r) && r > 0
      ? `El monstruo tendrá ${(r * CONFIG.game.hpPerTargetRep).toLocaleString('es-MX')} puntos de vida.`
      : 'Indica un número entero de contracciones.';
  }

  setHomeError(msg) {
    this.el['home-error'].textContent = msg;
  }

  renderHistory(sessions) {
    const box = this.el.history;
    if (!sessions) { box.innerHTML = '<p class="empty">Selecciona un paciente para ver sus sesiones.</p>'; return; }
    if (!sessions.length) { box.innerHTML = '<p class="empty">Este paciente aún no tiene sesiones registradas.</p>'; return; }
    const rows = [...sessions].reverse().map(s => `
      <tr>
        <td>${s.sessionNumber}</td>
        <td>${fmtDate(s.date)}</td>
        <td class="num">${s.repsCompleted} / ${s.targetReps}</td>
        <td class="num">${fmt1(s.avgPercent)} %</td>
        <td class="num">${s.totalDamage}</td>
        <td class="num">${fmtStoredSignal(s.mvc, s.signalUnit)}</td>
      </tr>`).join('');
    box.innerHTML = `<table>
      <thead><tr><th>Sesión</th><th>Fecha</th><th class="num">Contracciones</th><th class="num">% promedio</th><th class="num">Daño total</th><th class="num">Referencia</th></tr></thead>
      <tbody>${rows}</tbody></table>`;
  }

  // ------------------------------------------------------------------ calibración
  resetCalibration(patientName, sessionNumber) {
    this.el['cal-patient'].textContent = `${patientName}, sesión ${sessionNumber}`;
    this.el['cal-results'].hidden = true;
    this.el['cal-error'].textContent = '';
    this.el['btn-cal-start'].textContent = 'Iniciar calibración';
    this.el['btn-cal-start'].hidden = false;
    this.el['btn-cal-start'].disabled = false;
    this.el['btn-cal-continue'].hidden = true;
    this.el['cal-baseline-mark'].hidden = true;
  }

  setCalibrationRunning(running) {
    this.el['btn-cal-start'].disabled = running;
    if (running) {
      this.el['cal-results'].hidden = true;
      this.el['cal-error'].textContent = '';
      this.el['btn-cal-continue'].hidden = true;
      this.el['cal-baseline-mark'].hidden = true;
    }
  }

  updateCalibration(status, signal) {
    const { phase } = status;
    const activeStep = status.activeStep ?? -1;
    this.el['cal-steps'].querySelectorAll('li').forEach((li, i) => {
      li.classList.toggle('is-active', i === activeStep && phase !== CalPhase.DONE);
      li.classList.toggle('is-done', phase === CalPhase.DONE || (activeStep >= 0 && i < activeStep));
    });

    this.el['cal-instruction'].textContent = status.instruction || '';
    this.el['cal-count'].textContent = status.secondsLeft ? String(status.secondsLeft) : '';
    const isContraction = [CalPhase.CONTRACTION_1, CalPhase.CONTRACTION_2, CalPhase.CONTRACTION_3].includes(phase);
    this.el['cal-count'].style.color = isContraction ? 'var(--coral)' : '';
    this.el['cal-phase-fill'].style.width = `${status.progress * 100}%`;

    const mv = Math.max(0, Number(signal) || 0);
    this.el['cal-raw'].textContent = String(Math.round(mv));
    this.el['cal-meter'].style.width = `${calMeterPercent(mv)}%`;
    if (status.baseline !== null) {
      const mark = this.el['cal-baseline-mark'];
      mark.hidden = false;
      mark.style.left = `${calMeterPercent(status.baseline)}%`;
    }
  }

  showCalibrationResult({ baseline, mvc, peaks = [] }) {
    this.el['cal-baseline'].textContent = fmtSignal(baseline);
    this.el['cal-mvc'].textContent = fmtSignal(mvc);
    this.el['cal-range'].textContent = `${Math.round(mvc - baseline)} mV`;
    if (this.el['cal-peaks']) {
      this.el['cal-peaks'].textContent = peaks.filter(Number.isFinite).map(v => `${Math.round(v)} mV`).join(' · ') || '—';
    }
    this.el['cal-results'].hidden = false;
    this.el['btn-cal-start'].textContent = 'Repetir calibración';
    this.el['btn-cal-start'].disabled = false;
    this.el['btn-cal-continue'].hidden = false;
  }

  showCalibrationError(msg) {
    this.el['cal-error'].textContent = msg;
    this.el['btn-cal-start'].textContent = 'Repetir calibración';
    this.el['btn-cal-start'].disabled = false;
    this.el['btn-cal-continue'].hidden = true;
  }

  // ------------------------------------------------------------------ juego
  _placeThresholdMarks() {
    this.el['mark-start'].style.left = `${CONFIG.rep.startPercent}%`;
    this.el['mark-end'].style.left = `${CONFIG.rep.endPercent}%`;
  }

  setupGame({ patientName, sessionNumber, targetReps, mvc, maxHP }) {
    this.el['g-patient'].textContent = patientName;
    this.el['g-session'].textContent = sessionNumber;
    this.el['g-reps'].textContent = 0;
    this.el['g-target'].textContent = targetReps;
    this.el['g-mvc'].textContent = fmtSignal(mvc);
    this.el['last-damage'].textContent = '—';
    this.el['last-damage'].style.color = '';
    this.el['total-damage'].textContent = 0;
    this.el['current-peak'].textContent = '—';
    this.el.monster.classList.remove('hit', 'boss-wounded', 'boss-defeated');
    this.el.monster.dataset.phase = '1';
    this.el.monster.setAttribute('aria-label', 'Dragón de fuego');
    this.el['boss-stage'].textContent = 'FASE 1';
    this.el['boss-announcement'].textContent = '';
    this._setHP(maxHP, maxHP);
  }

  _setHP(hp, max) {
    this.el['hp-current'].textContent = hp.toLocaleString('es-MX');
    this.el['hp-max'].textContent = max.toLocaleString('es-MX');
    this.el['hp-fill'].style.width = `${max ? (hp / max) * 100 : 0}%`;
  }

  /** Se llama en cada cuadro: barra de contracción en vivo. */
  updateLive(percent, repState, peakPercent) {
    const p = Math.round(percent);
    this.el['pct-value'].textContent = p;
    const fill = this.el['pct-fill'];
    fill.style.width = `${percent}%`;
    fill.style.backgroundColor = attackColorFor(percent);

    const st = this.el['rep-state'];
    st.textContent = REP_STATE_TEXT[repState];
    st.classList.toggle('is-active', repState === RepState.CONTRACTING);

    const peak = this.el['pct-peak'];
    const active = repState !== RepState.REST && peakPercent > 0;
    peak.hidden = !active;
    if (active) peak.style.left = `${peakPercent}%`;
    this.el['current-peak'].textContent = active ? `${Math.round(peakPercent)} %` : '—';
  }

  /** Un disparo visual. No incrementa la cuenta de contracciones; solo aplica daño. */
  async playShot({ shot, monsterHP, monsterMaxHP, totalDamage, nextStage, finalDefeat }) {
    const color = attackColorFor(shot.percent);
    const stage = document.querySelector('.stage');
    const hero = this.el.hero, monster = this.el.monster, proj = this.el.projectile;
    const burst = this.el['impact-burst'];
    const s = stage.getBoundingClientRect();
    const o = hero.querySelector('.hero-orb').getBoundingClientRect();
    const m = monster.getBoundingClientRect();
    const x0 = o.left + o.width / 2 - s.left, y0 = o.top + o.height / 2 - s.top;
    const x1 = m.left + m.width * 0.42 - s.left, y1 = m.top + m.height * 0.5 - s.top;
    const angle = Math.atan2(y1 - y0, x1 - x0);
    const beamLength = Math.hypot(x1 - x0, y1 - y0);

    proj.style.setProperty('--attack-color', color);
    proj.style.width = `${beamLength}px`;
    proj.style.height = '32px';
    proj.style.background = `linear-gradient(90deg, transparent, ${color} 12%, #fff 47%, ${color} 84%, transparent)`;
    proj.style.boxShadow = `0 0 28px 10px ${color}99`;
    hero.classList.add('attacking');
    const anim = proj.animate([
      { transform: `translate(${x0}px, ${y0 - 16}px) rotate(${angle}rad) scaleX(.03)`, opacity: 0 },
      { transform: `translate(${x0}px, ${y0 - 16}px) rotate(${angle}rad) scaleX(1)`, opacity: 1, offset: .72 },
      { transform: `translate(${x0}px, ${y0 - 16}px) rotate(${angle}rad) scaleX(1)`, opacity: 0 },
    ], { duration: reducedMotion() ? 1 : CONFIG.game.attackDurationMs, easing: 'cubic-bezier(.2,.8,.25,1)' });
    await anim.finished.catch(() => {});
    hero.classList.remove('attacking');

    monster.classList.remove('hit');
    void monster.getBoundingClientRect();
    monster.classList.add('hit');
    burst.style.setProperty('--attack-color', color);
    burst.style.boxShadow = `0 0 0 8px ${color}55, 0 0 32px 18px ${color}aa`;
    burst.style.left = `${x1}px`;
    burst.style.top = `${y1}px`;
    burst.classList.remove('show');
    void burst.offsetWidth;
    burst.classList.add('show');
    stage.classList.remove('impact-shake');
    void stage.offsetWidth;
    stage.classList.add('impact-shake');
    this._setHP(monsterHP, monsterMaxHP);

    const pop = this.el['damage-pop'];
    pop.textContent = `DAÑO: ${shot.damage}`;
    pop.style.color = color;
    pop.classList.remove('show');
    void pop.offsetWidth;
    pop.classList.add('show');

    this.el['last-damage'].textContent = shot.damage;
    this.el['last-damage'].style.color = color;
    this.el['total-damage'].textContent = totalDamage;
    if (nextStage) await this.reviveBoss(nextStage, monsterMaxHP);
    else if (finalDefeat) {
      monster.classList.remove('hit');
      this.el['boss-announcement'].textContent = 'DRAGÓN DERROTADO · COMPLETA TUS REPETICIONES';
      const fall = monster.animate([
        { opacity: 1, transform: 'translateY(0)' },
        { opacity: 0, transform: 'translateY(30px)' }
      ], { duration: reducedMotion() ? 1 : 650, fill: 'forwards' });
      await fall.finished.catch(() => {});
      monster.classList.add('boss-defeated');
      monster.setAttribute('aria-label', 'Dragón muerto, objetivo para completar las repeticiones');
      fall.cancel();
      this.el['boss-announcement'].textContent = '';
      this.el['boss-stage'].textContent = 'FASE 3 · DERROTADO';
    }

  }

  async reviveBoss(nextStage, maxHP) {
    const monster = this.el.monster;
    const title = this.el['boss-announcement'];
    monster.classList.remove('hit');
    title.textContent = 'DRAGÓN DERROTADO';
    const death = monster.animate([
      { transform: 'translateY(0) rotate(0deg)', opacity: 1 },
      { transform: 'translateY(45px) rotate(8deg) scaleY(.7)', opacity: .15 }
    ], { duration: reducedMotion() ? 1 : 650, fill: 'forwards', easing: 'ease-in' });
    await death.finished.catch(() => {});
    monster.dataset.phase = String(nextStage);
    monster.classList.add('boss-wounded');
    const aura = nextStage === 2 ? '#20aaff' : '#c530ff';
    title.textContent = `FASE ${nextStage} · ${nextStage === 2 ? 'FURIA AZUL' : 'FURIA MORADA'}`;
    this.el['boss-stage'].textContent = `FASE ${nextStage}`;
    this._setHP(maxHP, maxHP);
    death.cancel();
    const rise = monster.animate([
      { transform: 'translateY(45px) scale(.85)', opacity: .15, filter: `brightness(2) drop-shadow(0 0 40px ${aura})` },
      { transform: 'translateY(0) scale(1)', opacity: 1, filter: `brightness(1) drop-shadow(0 0 16px ${aura})` }
    ], { duration: reducedMotion() ? 1 : 850, easing: 'ease-out' });
    await rise.finished.catch(() => {});
    title.textContent = '';
  }

  completeRep(rep, targetReps) {
    this.el['g-reps'].textContent = rep.index;
    this.el['g-target'].textContent = targetReps;
    this.el['current-peak'].textContent = '—';
  }

  // ------------------------------------------------------------------ resumen
  showSummary(summary, record) {
    this.el['summary-reps'].innerHTML = contractionTable(record.reps);
    this.el['sum-subtitle'].textContent = `${record.patientName}, sesión ${record.sessionNumber}, ${fmtDate(record.date)}`;
    const best = summary.bestRep ? `Contr. ${summary.bestRep.index}: ${fmt1(summary.bestRep.peakPercent)} %` : '—';
    this.el['summary-grid'].innerHTML = [
      ['Contracciones completadas', `${summary.repsCompleted} / ${summary.targetReps}`],
      ['Daño total', summary.totalDamage.toLocaleString('es-MX')],
      ['Tiempo acumulado de contracción', `${((record.reps || []).reduce((sum, r) => sum + (Number(r.durationMs) || 0), 0) / 1000).toFixed(2)} s`],
      ['Porcentaje medio', `${fmt1(summary.avgPercent)} %`],
      ['Mejor contracción', best],
      ['Referencia de la sesión', fmtSignal(summary.mvc)],
      ['Disparos totales', summary.totalShots ?? 0],
      ['Vida restante del monstruo', `${summary.monsterHPRemaining} / ${summary.monsterMaxHP} HP`],
    ].map(([k, v]) => `<div><span>${k}</span><strong>${v}</strong></div>`).join('');

    this.el['summary-chart'].innerHTML = barChart(
      record.reps.map(r => ({ label: String(r.index), value: r.peakPercent, color: attackColorFor(r.peakPercent) })),
      { max: 100, unit: '%' });
  }

  // ------------------------------------------------------------------ progreso
  showProgress(patient, sessions) {
    this.el['prog-patient'].textContent = patient.name;
    const stats = this.el['prog-stats'];
    if (!sessions.length) {
      stats.innerHTML = '<p class="empty">Aún no hay sesiones registradas para este paciente.</p>';
      this.el['prog-chart-pct'].innerHTML = '';
      this.el['prog-chart-mvc'].innerHTML = '';
      this.el['prog-table'].innerHTML = '';
      return;
    }
    const histAvg = sessions.reduce((a, s) => a + s.avgPercent, 0) / sessions.length;
    const best = sessions.reduce((b, s) => (s.avgPercent > b.avgPercent ? s : b));
    const last = sessions[sessions.length - 1];
    const first = sessions[0];
    const firstRef = storedToMv(first.mvc, first.signalUnit);
    const lastRef = storedToMv(last.mvc, last.signalUnit);
    const mvcChange = firstRef ? ((lastRef - firstRef) / firstRef) * 100 : 0;

    stats.innerHTML = [
      ['Promedio histórico', `${fmt1(histAvg)} %`],
      ['Mejor sesión', `Sesión ${best.sessionNumber}: ${fmt1(best.avgPercent)} %`],
      ['Última referencia', fmtStoredSignal(last.mvc, last.signalUnit)],
      ['Cambio de referencia', sessions.length > 1 ? `${mvcChange >= 0 ? '+' : ''}${fmt1(mvcChange)} %` : '—'],
      ['Sesiones registradas', sessions.length],
    ].map(([k, v]) => `<div><span>${k}</span><strong>${v}</strong></div>`).join('');

    this.el['prog-chart-pct'].innerHTML = barChart(
      sessions.map(s => ({ label: `S${s.sessionNumber}`, value: s.avgPercent, color: '#0E8C7F' })),
      { max: 100, unit: '%' });
    this.el['prog-chart-mvc'].innerHTML = lineChart(
      sessions.map(s => ({ label: `S${s.sessionNumber}`, value: storedToMv(s.mvc, s.signalUnit) || 0 })),
      { unit: ' mV', decimals: 0 });

    this.el['prog-table'].innerHTML = `<table>
      <thead><tr><th>Sesión</th><th>Fecha</th><th class="num">Contracciones</th><th class="num">% promedio</th>
      <th class="num">Mejor contr.</th><th class="num">Daño total</th><th class="num">Baseline</th><th class="num">Referencia</th><th class="num">HP restante</th></tr></thead>
      <tbody>${sessions.map(s => `<tr>
        <td>${s.sessionNumber}</td><td>${fmtDate(s.date)}</td>
        <td class="num">${s.repsCompleted} / ${s.targetReps}</td>
        <td class="num">${fmt1(s.avgPercent)} %</td>
        <td class="num">${s.bestRep ? `${fmt1(s.bestRep.peakPercent)} %` : '—'}</td>
        <td class="num">${s.totalDamage}</td>
        <td class="num">${fmtStoredSignal(s.baseline, s.signalUnit)}</td>
        <td class="num">${fmtStoredSignal(s.mvc, s.signalUnit)}</td>
        <td class="num">${s.monsterHPRemaining}</td></tr><tr><td colspan="9"><details><summary>Ver duración y daño de cada contracción</summary>${contractionTable(s.reps || [])}</details></td></tr>`).join('')}</tbody></table>`;
  }
}

function contractionTable(reps) {
  if (!reps.length) return '<p class="empty">Las contracciones aparecerán aquí al relajarte.</p>';
  const number = value => Number.isFinite(Number(value)) && value != null ? Number(value) : null;
  return `<table><thead><tr><th>Contracción</th><th class="num">Duración (s)</th><th class="num">Golpes</th><th class="num">Daño (puntos)</th><th class="num">Pico (%)</th></tr></thead><tbody>${reps.map(r => {
    const duration = number(r.durationMs);
    return `<tr><td>${number(r.index) ?? '—'}</td><td class="num">${duration === null ? '—' : (duration / 1000).toFixed(2)}</td><td class="num">${number(r.shots) ?? '—'}</td><td class="num">${number(r.damage) ?? '—'}</td><td class="num">${number(r.peakPercent) === null ? '—' : Number(r.peakPercent).toFixed(1)}</td></tr>`;
  }).join('')}</tbody></table>`;
}

// ---------------------------------------------------------------------- gráficas SVG
const W = 720, H = 250, PAD = { l: 50, r: 14, t: 28, b: 36 };

function barChart(items, { max = 100, unit = '' } = {}) {
  if (!items.length) return '<p class="empty">Sin datos.</p>';
  const iw = W - PAD.l - PAD.r, ih = H - PAD.t - PAD.b;
  const slot = iw / items.length;
  const bw = Math.min(54, slot * 0.62);
  const grid = [0, 25, 50, 75, 100].map(g => {
    const y = PAD.t + ih - (g / max) * ih;
    return `<line x1="${PAD.l}" x2="${W - PAD.r}" y1="${y}" y2="${y}" stroke="#D5DEE6"/>
      <text x="${PAD.l - 8}" y="${y + 4}" text-anchor="end" font-size="14" fill="#4E6679">${g}${unit}</text>`;
  }).join('');
  const bars = items.map((it, i) => {
    const h = (Math.min(it.value, max) / max) * ih;
    const x = PAD.l + slot * i + (slot - bw) / 2;
    const y = PAD.t + ih - h;
    const showLabels = items.length <= 24;
    return `<rect x="${x}" y="${y}" width="${bw}" height="${Math.max(h, 1)}" rx="5" fill="${it.color}"/>
      ${showLabels ? `<text x="${x + bw / 2}" y="${y - 6}" text-anchor="middle" font-size="14" font-weight="700" fill="#12324A">${Math.round(it.value)}</text>` : ''}
      ${showLabels ? `<text x="${x + bw / 2}" y="${H - 12}" text-anchor="middle" font-size="14" fill="#4E6679">${escapeHtml(it.label)}</text>` : ''}`;
  }).join('');
  return `<svg viewBox="0 0 ${W} ${H}" role="img" font-family="inherit">${grid}${bars}</svg>`;
}

function lineChart(items, { unit = '', decimals = 0 } = {}) {
  if (!items.length) return '<p class="empty">Sin datos.</p>';
  const iw = W - PAD.l - PAD.r, ih = H - PAD.t - PAD.b;
  const maxV = Math.max(...items.map(i => i.value)) * 1.15 || 1;
  const step = items.length > 1 ? iw / (items.length - 1) : 0;
  const pts = items.map((it, i) => ({
    x: PAD.l + (items.length > 1 ? step * i : iw / 2),
    y: PAD.t + ih - (it.value / maxV) * ih,
    ...it,
  }));
  const grid = [0, 0.5, 1].map(f => {
    const y = PAD.t + ih - f * ih;
    return `<line x1="${PAD.l}" x2="${W - PAD.r}" y1="${y}" y2="${y}" stroke="#D5DEE6"/>
      <text x="${PAD.l - 8}" y="${y + 4}" text-anchor="end" font-size="14" fill="#4E6679">${(maxV * f).toFixed(decimals)}${unit}</text>`;
  }).join('');
  const showLabels = items.length <= 24;
  return `<svg viewBox="0 0 ${W} ${H}" role="img" font-family="inherit">${grid}
    <polyline points="${pts.map(p => `${p.x},${p.y}`).join(' ')}" fill="none" stroke="#12324A" stroke-width="3" stroke-linejoin="round"/>
    ${pts.map(p => `<circle cx="${p.x}" cy="${p.y}" r="6" fill="#fff" stroke="#12324A" stroke-width="3"/>
      ${showLabels ? `<text x="${p.x}" y="${p.y - 12}" text-anchor="middle" font-size="14" font-weight="700" fill="#12324A">${p.value.toFixed(decimals)}${unit}</text>
      <text x="${p.x}" y="${H - 12}" text-anchor="middle" font-size="14" fill="#4E6679">${escapeHtml(p.label)}</text>` : ''}`).join('')}
  </svg>`;
}
