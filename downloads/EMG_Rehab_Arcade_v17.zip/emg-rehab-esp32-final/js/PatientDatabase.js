/**
 * PatientDatabase.js
 * Almacenamiento local con IndexedDB.
 *   - Almacén "patients": { id, name, createdAt }
 *   - Almacén "sessions": { id, patientId, patientName, date, sessionNumber, ... }
 * Incluye exportación a CSV/JSON e importación de JSON.
 */
const DB_NAME = 'semg-rehab';
const DB_VERSION = 1;
const legacyAdcToMv = (adc) => (Number(adc) * 5.0 / 16383) * 1000;
const storedToMv = (value, unit) => unit === 'mV' ? Number(value) : legacyAdcToMv(value);

export class PatientDatabase {
  async open() {
    this.db = await new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('patients')) {
          const p = db.createObjectStore('patients', { keyPath: 'id', autoIncrement: true });
          p.createIndex('name', 'nameKey', { unique: true });
        }
        if (!db.objectStoreNames.contains('sessions')) {
          const s = db.createObjectStore('sessions', { keyPath: 'id', autoIncrement: true });
          s.createIndex('patientId', 'patientId', { unique: false });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return this;
  }

  _store(name, mode = 'readonly') {
    return this.db.transaction(name, mode).objectStore(name);
  }

  _req(request) {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  static nameKey(name) {
    return name.trim().toLowerCase().replace(/\s+/g, ' ');
  }

  // ---------- Pacientes ----------
  async getPatients() {
    const list = await this._req(this._store('patients').getAll());
    return list.sort((a, b) => a.name.localeCompare(b.name, 'es'));
  }

  async getPatient(id) {
    return this._req(this._store('patients').get(id));
  }

  async findPatientByName(name) {
    return this._req(this._store('patients').index('name').get(PatientDatabase.nameKey(name)));
  }

  async getOrCreatePatient(name) {
    const existing = await this.findPatientByName(name);
    if (existing) return existing;
    const patient = { name: name.trim(), nameKey: PatientDatabase.nameKey(name), createdAt: new Date().toISOString() };
    patient.id = await this._req(this._store('patients', 'readwrite').add(patient));
    return patient;
  }

  // ---------- Sesiones ----------
  async getSessions(patientId) {
    const list = await this._req(this._store('sessions').index('patientId').getAll(patientId));
    return list.sort((a, b) => a.sessionNumber - b.sessionNumber || a.date.localeCompare(b.date));
  }

  async getAllSessions() {
    return this._req(this._store('sessions').getAll());
  }

  async addSession(record) {
    record.id = await this._req(this._store('sessions', 'readwrite').add({ ...record }));
    return record;
  }

  async nextSessionNumber(patientId) {
    const sessions = await this.getSessions(patientId);
    return sessions.reduce((m, s) => Math.max(m, s.sessionNumber), 0) + 1;
  }

  // ---------- Exportación ----------
  async exportJSON(patientId = null) {
    const patients = patientId ? [await this.getPatient(patientId)] : await this.getPatients();
    const sessions = patientId ? await this.getSessions(patientId) : await this.getAllSessions();
    return {
      app: 'semg-rehab',
      version: 1,
      exportedAt: new Date().toISOString(),
      patients: patients.map(({ id, name, createdAt }) => ({ id, name, createdAt })),
      sessions,
    };
  }

  /** CSV con una fila por repetición e información de la sesión en cada fila. */
  async exportCSV(patientId = null) {
    const sessions = patientId ? await this.getSessions(patientId) : await this.getAllSessions();
    const header = [
      'paciente', 'fecha', 'sesion', 'contracciones_objetivo', 'baseline_mV', 'referencia_mV',
      'contraccion', 'pico_mV', 'pico_porcentaje', 'disparos', 'dano', 'duracion_ms', 'duracion_s',
      'disparos_totales_sesion', 'dano_total_sesion', 'porcentaje_promedio_sesion',
      'mejor_contraccion', 'mejor_porcentaje', 'hp_restante',
    ];
    const rows = [header];
    for (const s of sessions) {
      for (const r of s.reps) {
        rows.push([
          s.patientName, s.date, s.sessionNumber, s.targetReps,
          Math.round(storedToMv(s.baseline, s.signalUnit) * 10) / 10,
          Math.round(storedToMv(s.mvc, s.signalUnit) * 10) / 10,
          r.index,
          Math.round(storedToMv(r.peakRaw, s.signalUnit) * 10) / 10,
          r.peakPercent, r.shots ?? '', r.damage, r.durationMs, Number.isFinite(r.durationMs) ? r.durationMs / 1000 : '',
          s.totalShots ?? '', s.totalDamage, s.avgPercent,
          s.bestRep?.index ?? '', s.bestRep?.peakPercent ?? '', s.monsterHPRemaining,
        ]);
      }
    }
    return rows.map(row => row.map(csvCell).join(',')).join('\r\n');
  }

  // ---------- Importación ----------
  /** Combina un JSON exportado con lo existente. Omite sesiones duplicadas. */
  async importJSON(data) {
    if (!data || !Array.isArray(data.patients) || !Array.isArray(data.sessions)) {
      throw new Error('El archivo no tiene el formato de exportación de esta aplicación.');
    }
    const idMap = new Map();
    for (const p of data.patients) {
      if (!p?.name) continue;
      const local = await this.getOrCreatePatient(p.name);
      idMap.set(p.id, local);
    }
    let added = 0, skipped = 0;
    for (const s of data.sessions) {
      const patient = idMap.get(s.patientId) || (s.patientName && await this.getOrCreatePatient(s.patientName));
      if (!patient || !Array.isArray(s.reps)) { skipped++; continue; }
      const existing = await this.getSessions(patient.id);
      const dup = existing.some(e => e.date === s.date && e.sessionNumber === s.sessionNumber);
      if (dup) { skipped++; continue; }
      const { id, ...rest } = s;
      await this.addSession({ ...rest, patientId: patient.id, patientName: patient.name });
      added++;
    }
    return { added, skipped };
  }
}

function csvCell(v) {
  const s = String(v ?? '');
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
