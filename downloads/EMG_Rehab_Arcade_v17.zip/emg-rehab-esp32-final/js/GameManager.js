/**
 * GameManager.js
 * Cada contracción cuenta como UNA repetición clínica.
 * Mientras se sostiene >= 60 %, puede generar varios disparos.
 * Cada disparo aplica daño según su propio porcentaje de activación.
 * Una contracción sostenida puede lanzar varios golpes, cada uno con su daño.
 */
import { clamp, CONFIG } from './config.js?v=20261102-17';

export class GameManager {
  constructor({ hpPerTargetRep = 100 } = {}) {
    this.hpPerTargetRep = hpPerTargetRep;
    this.session = null;
  }

  startSession({ patient, sessionNumber, targetReps, baseline, mvc }) {
    const maxHP = targetReps * this.hpPerTargetRep;
    this.session = {
      patient,
      sessionNumber,
      targetReps,
      baseline,
      mvc,
      signalUnit: 'mV',
      monsterMaxHP: maxHP,
      monsterHP: maxHP,
      bossStage: 1,
      reps: [],
      currentContractionDamage: 0,
      currentContractionShots: 0,
      startedAt: new Date(),
      finished: false,
    };
    return this.session;
  }

  get isActive() {
    return !!this.session && !this.session.finished;
  }

  beginContraction() {
    if (!this.session) return;
    this.session.currentContractionDamage = 0;
    this.session.currentContractionShots = 0;
  }

  registerShot({ percent, raw, shotNumber }) {
    const s = this.session;
    if (!s || s.finished) return null;

    if (shotNumber === 1) this.beginContraction();

    const wasDefeated = s.monsterHP === 0;

    const nominal = Math.max(CONFIG.game.minShotDamage, Math.round(percent * CONFIG.game.shotDamageScale));
    const damage = nominal;

    s.currentContractionShots++;
    s.currentContractionDamage += damage;
    s.monsterHP = Math.max(0, s.monsterHP - damage);

    const hitHP = s.monsterHP;
    const defeated = !wasDefeated && hitHP === 0;
    const nextStage = defeated && s.bossStage < 3 && s.reps.length < s.targetReps ? s.bossStage + 1 : null;
    if (nextStage) {
      s.bossStage = nextStage;
      s.monsterHP = s.monsterMaxHP;
    }

    return {
      nextStage,
      finalDefeat: defeated && !nextStage,
      shot: {
        percent: Math.round(percent * 10) / 10,
        raw: Math.round(raw),
        damage,
        shotNumber: s.currentContractionShots,
      },
      monsterHP: hitHP,
      monsterMaxHP: s.monsterMaxHP,
      totalDamage: this._totalDamageIncludingCurrent(),
    };
  }

  registerRep({ peakPercent, peakRaw, durationMs, shots }) {
    const s = this.session;
    if (!s || s.finished) return null;

    const rep = {
      index: s.reps.length + 1,
      peakRaw: Math.round(peakRaw),
      peakPercent: Math.round(peakPercent * 10) / 10,
      damage: s.currentContractionDamage,
      shots: Math.max(shots || 0, s.currentContractionShots),
      durationMs: Math.round(durationMs),
      timestamp: new Date().toISOString(),
    };
    s.reps.push(rep);
    s.currentContractionDamage = 0;
    s.currentContractionShots = 0;

    if (s.reps.length >= s.targetReps) s.finished = true;

    return {
      rep,
      monsterHP: s.monsterHP,
      monsterMaxHP: s.monsterMaxHP,
      finished: s.finished,
    };
  }

  _totalDamageIncludingCurrent() {
    const s = this.session;
    if (!s) return 0;
    return s.reps.reduce((a, r) => a + r.damage, 0) + s.currentContractionDamage;
  }

  summary() {
    const s = this.session;
    const reps = s.reps;
    const totalDamage = reps.reduce((a, r) => a + r.damage, 0);
    const avgPercent = reps.length ? reps.reduce((a, r) => a + r.peakPercent, 0) / reps.length : 0;
    const best = reps.reduce((b, r) => (!b || r.peakPercent > b.peakPercent ? r : b), null);
    const totalShots = reps.reduce((a, r) => a + (r.shots || 0), 0);
    return {
      repsCompleted: reps.length,
      targetReps: s.targetReps,
      totalDamage,
      totalShots,
      avgPercent: Math.round(avgPercent * 10) / 10,
      bestRep: best ? { index: best.index, peakPercent: best.peakPercent, damage: best.damage, shots: best.shots } : null,
      baseline: s.baseline,
      mvc: s.mvc,
      monsterMaxHP: s.monsterMaxHP,
      monsterHPRemaining: s.monsterHP,
    };
  }

  toRecord() {
    const s = this.session;
    const sum = this.summary();
    return {
      patientId: s.patient.id,
      patientName: s.patient.name,
      date: s.startedAt.toISOString(),
      sessionNumber: s.sessionNumber,
      targetReps: s.targetReps,
      baseline: Math.round(s.baseline * 10) / 10,
      mvc: Math.round(s.mvc * 10) / 10,
      signalUnit: 'mV',
      reps: s.reps,
      repsCompleted: sum.repsCompleted,
      totalShots: sum.totalShots,
      totalDamage: sum.totalDamage,
      avgPercent: sum.avgPercent,
      bestRep: sum.bestRep,
      monsterMaxHP: sum.monsterMaxHP,
      monsterHPRemaining: sum.monsterHPRemaining,
    };
  }

  endSession() {
    this.session = null;
  }
}
