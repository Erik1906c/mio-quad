/**
 * RepDetector.js
 * Una contracción clínica sigue siendo UNA repetición, pero puede producir varios disparos:
 *   - primer disparo al superar 50 % durante 130 ms (rechaza picos aislados);
 *   - otro disparo cada 1000 ms mientras siga >= 50 %;
 *   - la contracción termina cuando baja de 40 % y permanece relajada 300 ms.
 */
export const RepState = {
  REST: 'REST',
  CONTRACTING: 'CONTRACTING',
  RETURNING: 'RETURNING',
};

export class RepDetector {
  constructor(cfg) {
    this.cfg = cfg;
    this.reset();
  }

  reset() {
    this.state = RepState.REST;
    this.startTime = 0;
    this.belowSince = 0;
    this.peakPercent = 0;
    this.peakRaw = 0;
    this.cooldownUntil = 0;
    this.lastShotAt = 0;
    this.shots = 0;
    this.candidateSince = null;
    this.candidatePeakPercent = 0;
    this.candidatePeakRaw = 0;
  }

  update(percent, raw, t) {
    const c = this.cfg;
    const out = { shot: null, rep: null, started: false };

    switch (this.state) {
      case RepState.REST:
        if (t < this.cooldownUntil || percent <= c.startPercent) {
          this.candidateSince = null;
          this.candidatePeakPercent = 0;
          this.candidatePeakRaw = 0;
          return null;
        }

        if (this.candidateSince === null) {
          this.candidateSince = t;
          this.candidatePeakPercent = percent;
          this.candidatePeakRaw = raw;
          return null;
        }

        if (t - this.candidateSince >= (c.activationConfirmMs ?? 130)) {
          this.state = RepState.CONTRACTING;
          this.startTime = this.candidateSince;
          this.peakPercent = Math.max(this.candidatePeakPercent, percent);
          this.peakRaw = Math.max(this.candidatePeakRaw, raw);
          this.lastShotAt = t;
          this.shots = 1;
          this.candidateSince = null;
          out.started = true;
          out.shot = { percent, raw, shotNumber: this.shots };
          return out;
        }
        return null;

      case RepState.CONTRACTING:
        this._trackPeak(percent, raw);

        if (percent < c.endPercent) {
          this.state = RepState.RETURNING;
          this.belowSince = t;
          return null;
        }

        if (percent > c.startPercent && t - this.lastShotAt >= c.shotIntervalMs) {
          this.lastShotAt = t;
          this.shots++;
          out.shot = { percent, raw, shotNumber: this.shots };
          return out;
        }
        return null;

      case RepState.RETURNING:
        if (percent >= c.endPercent) {
          this._trackPeak(percent, raw);
          this.state = RepState.CONTRACTING;
          // Si regresó por encima de 50 % y ya pasó el intervalo, puede disparar de nuevo.
          if (percent > c.startPercent && t - this.lastShotAt >= c.shotIntervalMs) {
            this.lastShotAt = t;
            this.shots++;
            out.shot = { percent, raw, shotNumber: this.shots };
            return out;
          }
          return null;
        }

        if (t - this.belowSince >= c.relaxHoldMs) {
          const durationMs = this.belowSince - this.startTime;
          const rep = {
            peakPercent: this.peakPercent,
            peakRaw: this.peakRaw,
            durationMs,
            shots: this.shots,
          };
          this.state = RepState.REST;
          this.cooldownUntil = t + c.cooldownMs;
          this.peakPercent = 0;
          this.peakRaw = 0;
          this.shots = 0;
          if (durationMs < c.minRepMs) return null;
          out.rep = rep;
          return out;
        }
        return null;
    }
    return null;
  }

  _trackPeak(percent, raw) {
    if (percent > this.peakPercent) this.peakPercent = percent;
    if (raw > this.peakRaw) this.peakRaw = raw;
  }
}
