# EMG Rehab — versión ESP32 WiFi

Versión adaptada del juego de biofeedback sEMG para el montaje validado con ESP32.

## Qué cambió

- Arduino R4 sustituido por **ESP32**.
- El ESP32 crea la red WiFi **EMG-Rehab** (contraseña `12345678`).
- La laptop recibe la señal **inalámbricamente** desde `192.168.4.1`.
- El ESP32 conserva una cola de muestras de juego tomadas a **23 Hz** (una cada ~43.5 ms) y las entrega por lotes. Así la demora de las peticiones HTTP no reduce el ritmo de datos ni omite las pausas breves entre contracciones.
- El notch de 60 Hz conserva los coeficientes que ya se validaron a **1 kHz**.
- GPIO34 recibe el band-pass con offset cercano a 1.65 V.
- GPIO25 entrega el notch al restador analógico; el offset se quita **analógicamente**, no por código.
- GPIO35 lee la salida final (rectificador → envolvente → amplificador final).
- La señal enviada al juego es un **promedio móvil de 250 ms** de GPIO35.
- Calibración segura: **reposo + 3 contracciones cómodas**, no una MVC única.
- La referencia del 100 % es la **mediana de las 3 contracciones**.
- Primer disparo al superar **60 % durante 130 ms** para ignorar picos aislados.
- Mientras siga ≥60 %, dispara otra vez cada **500 ms**.
- Para terminar/rearmar una contracción debe bajar de **50 %** durante 300 ms.
- El daño por disparo corresponde al porcentaje de activación (por ejemplo, 80 % causa 80 HP); el daño de una contracción se limita a 100 HP.
- Una contracción clínica sigue contando como **una sola contracción**, aunque produzca varios disparos.

## Conexiones ESP32

| ESP32 | Circuito |
|---|---|
| `3V3` | divisor que crea la referencia de ~1.65 V |
| `GND` | 0 V común del circuito |
| `GPIO34 / D34` | salida del band-pass + offset |
| `GPIO25 / D25` | entrada positiva del restador a través de la resistencia correspondiente |
| `GPIO35 / D35` | salida del amplificador final (en el montaje probado: mediante 51 kΩ + 51 kΩ en serie) |

El circuito analógico sigue alimentado con **+9 V / 0 V / -9 V** mediante las dos baterías.
Nunca conectes +9 V o -9 V al ESP32.

## 1. Cargar el firmware al ESP32

1. Abre `esp32/EMG_Rehab_ESP32_Game.ino` en Arduino IDE.
2. Selecciona tu placa ESP32 y el puerto COM.
3. Deja `Upload Speed = 115200` si esa es la velocidad estable de tu placa.
4. Sube el sketch con los electrodos desconectados.
5. En esta placa, si hace falta, mantén **BOOT** durante `Connecting...` y suéltalo cuando empiece `Writing...`.
6. El monitor serie a 115200 debe mostrar:

```text
EMG Rehab ESP32 iniciado
Red WiFi: EMG-Rehab
IP: 192.168.4.1
```

## 2. Probar la conexión del juego

1. Sube `esp32/EMG_Rehab_ESP32_Game.ino` al ESP32. El monitor serial a 115200 debe mostrar `EMG Rehab ESP32 iniciado`, la red `EMG-Rehab` y la IP `192.168.4.1`.
2. Conecta la laptop a `EMG-Rehab` con contraseña `12345678`. Si Windows dice “Sin Internet”, elige permanecer conectado.
3. Antes de abrir el juego, visita `http://192.168.4.1/datos`. Debe aparecer JSON que incluya el campo `"signal"`. Si no carga, la falla está en la conexión WiFi o en el firmware cargado.
4. Ejecuta `INICIAR_JUEGO.bat` desde esta carpeta y espera a que abra el juego en `localhost`.
5. Pulsa `Conectar ESP32`. Si falla, abre primero `http://192.168.4.1/` y después `http://192.168.4.1/datos` desde la misma laptop. Si ninguno abre, Windows no está usando la red `EMG-Rehab` o el ESP32 no está respondiendo; si ambos abren, recarga el juego con `Ctrl+F5` y vuelve a conectar. El juego espera hasta 3 segundos por respuesta.

La laptop debe permanecer conectada a `EMG-Rehab` mientras el juego consulta el ESP32. El servidor del juego corre en la misma laptop; no requiere que la laptop tenga Internet.

## 3. Seguridad de las pruebas

Este prototipo académico no está verificado como equipo médicamente aislado. **No conectes electrodos a una persona.** Usar una power bank y baterías de ±9 V no demuestra por sí solo que las corrientes de fuga y las conexiones estén aisladas. Para depurar el juego, usa el modo simulación o una señal de banco sin persona conectada.

## 4. Calibración

La calibración ya no pide una contracción máxima única.

1. **Reposo — 3 s**: relajar completamente.
2. **Contracción 1 — 3 s**: fuerte pero cómoda, controlada y sin dolor.
3. **Descanso — 4 s**.
4. **Contracción 2 — 3 s**.
5. **Descanso — 4 s**.
6. **Contracción 3 — 3 s**.

Para cada contracción se toma el mejor nivel sostenido recibido. La referencia del 100 % es la **mediana** de las tres contracciones.

La activación se calcula como:

```text
activación = (señal_sostenida - reposo) / (referencia - reposo) × 100
```

limitada a 0–100 %.

## 5. Juego

- Al permanecer por encima de **60 % durante 130 ms**: primer disparo.
- Si mantiene ≥60 %: otro disparo cada **500 ms**.
- Si baja de 60 % pero todavía no baja de 50 %, no se generan disparos nuevos.
- Al permanecer <50 % durante 300 ms, se cierra la contracción y se registra **una contracción clínica**.
- Una contracción puede generar varios disparos, pero no cuenta como varias repeticiones.
- El daño acumulado por una sola contracción se limita a 100 HP.

## 6. Archivos principales

```text
emg-rehab-esp32-final/
├── index.html
├── css/styles.css
├── js/
│   ├── app.js
│   ├── ESP32Manager.js
│   ├── CalibrationManager.js
│   ├── RepDetector.js
│   ├── GameManager.js
│   ├── SignalProcessor.js
│   ├── SimulationSource.js
│   ├── PatientDatabase.js
│   ├── UIManager.js
│   └── config.js
├── esp32/
│   └── EMG_Rehab_ESP32_Game.ino
├── emg-server.exe
├── INICIAR_JUEGO.bat
└── STOP_JUEGO.bat
```

## Nota de alcance

Este proyecto es una plataforma de biofeedback/rehabilitación académica. No realiza diagnóstico médico. Los niveles de esfuerzo y el protocolo de ejercicio deben ajustarse a las indicaciones del equipo clínico responsable.


### Modo de prueba
El valor del deslizador ahora permanece activo al soltar el mouse. Para terminar la contracción simulada, baja el deslizador a 0; así no cae la señal a reposo accidentalmente mientras se prueba el daño.
