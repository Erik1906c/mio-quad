@echo off
setlocal
cd /d "%~dp0"
if not exist "emg-server.exe" (
  echo No se encontro emg-server.exe
  echo Verifica que este archivo este en la carpeta del juego.
  pause
  exit /b 1
)
echo Iniciando EMG Rehab...
taskkill /IM emg-server.exe /F >nul 2>&1
timeout /t 1 /nobreak >nul
start "EMG Rehab Server" /min "emg-server.exe"
timeout /t 2 /nobreak >nul
start "" "http://localhost:8000/?v=20261027-1"
echo.
echo El juego se esta abriendo en el navegador.
echo No cierres el servidor minimizado mientras uses el juego.
echo Para terminar, ejecuta STOP_JUEGO.bat
exit /b 0
