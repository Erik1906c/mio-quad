#include <WiFi.h>
#include <WebServer.h>

// =====================================================
// EMG Rehab - ESP32
//
// GPIO34 : entrada del band-pass con offset ~1.65 V
// GPIO25 : DAC -> restador analogico
// GPIO35 : salida final (rectificador -> envolvente -> amp final)
//
// Fs del notch = 1000 Hz
// El offset NO se elimina por software.
// El restador analogico elimina la referencia despues del DAC.
// =====================================================

// ---------------- WiFi ----------------
const char* WIFI_SSID = "EMG-Rehab";
const char* WIFI_PASS = "12345678";

WebServer server(80);

// ---------------- Pines ----------------
const int PIN_ENTRADA = 34;
const int PIN_DAC     = 25;
const int PIN_FINAL   = 35;

// ---------------- Muestreo ----------------
const uint32_t FS = 1000;
const uint32_t TS_US = 1000000UL / FS;
uint32_t tAnterior = 0;

// =====================================================
// NOTCH 60 Hz - mismos coeficientes validados
// =====================================================
const float b0 =  0.994643210262664f;
const float b1 = -1.849591737501258f;
const float b2 =  0.994643210262664f;
const float a1 = -1.849591737501258f;
const float a2 =  0.989286420525329f;

float z1_1 = 0.0f;
float z2_1 = 0.0f;
float z1_2 = 0.0f;
float z2_2 = 0.0f;

// =====================================================
// Promedio movil de 250 ms sobre la salida final D35
// Es la senal que recibe el juego.
// =====================================================
const int N_SOSTENIDO = 250;
int bufferFinal[N_SOSTENIDO];
long sumaFinal = 0;
int indiceFinal = 0;

volatile int finalInstantaneo_mV = 0;
volatile int finalSostenido_mV = 0;

// Telemetría por lotes: una muestra cada ~43.5 ms (23 Hz), aunque una petición
// HTTP tarde más. El procesamiento EMG sigue funcionando a 1 kHz.
const uint32_t TELEMETRY_PERIOD_US = 1000000UL / 23;
const uint16_t TELEMETRY_CAPACITY = 256;
struct TelemetrySample { uint32_t t; int signal; };
TelemetrySample telemetry[TELEMETRY_CAPACITY];
uint16_t telemetryHead = 0;
uint16_t telemetryTail = 0;
uint16_t telemetryCount = 0;
uint32_t nextTelemetryUs = 0;
uint32_t telemetryDropped = 0;

// Diagnostico
volatile int d34Vpp_mV = 0;
volatile int notchVpp_mV = 0;
volatile int dacActual = 128;

const int N_DIAG = 200;
int diagCount = 0;
int d34Min = 10000;
int d34Max = 0;
int notchMin = 10000;
int notchMax = 0;

// =====================================================
// Notch
// =====================================================
float notch60(float x, float &z1, float &z2) {
  float y = b0 * x + z1;
  z1 = b1 * x - a1 * y + z2;
  z2 = b2 * x - a2 * y;
  return y;
}

// =====================================================
// CORS + endpoint JSON
// =====================================================
void addCors() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
  server.sendHeader("Access-Control-Allow-Private-Network", "true");
  server.sendHeader("Cache-Control", "no-store");
}

void handleOptions() {
  addCors();
  server.send(204, "text/plain", "");
}

void handleDatos() {
  addCors();

  String json = "{";
  json += "\"signal\":" + String(finalSostenido_mV);
  json += ",\"raw\":" + String(finalInstantaneo_mV);
  json += ",\"d34vpp\":" + String(d34Vpp_mV);
  json += ",\"notchvpp\":" + String(notchVpp_mV);
  json += ",\"dac\":" + String(dacActual);
  json += ",\"uptime\":" + String(millis());
  json += ",\"dropped\":" + String(telemetryDropped);
  json += ",\"samples\":[";
  bool comma = false;
  while (telemetryCount > 0) {
    const TelemetrySample sample = telemetry[telemetryTail];
    telemetryTail = (telemetryTail + 1) % TELEMETRY_CAPACITY;
    telemetryCount--;
    if (comma) json += ",";
    json += "{\"t\":" + String(sample.t) + ",\"signal\":" + String(sample.signal) + "}";
    comma = true;
  }
  json += "]";
  json += "}";

  server.send(200, "application/json", json);
}

void handleRoot() {
  addCors();
  server.send(
    200,
    "text/plain",
    "EMG-Rehab ESP32 activo. Abre el juego en la laptop y pulsa Conectar ESP32."
  );
}

// =====================================================
// Setup
// =====================================================
void setup() {
  Serial.begin(115200);

  analogReadResolution(12);
  analogSetPinAttenuation(PIN_ENTRADA, ADC_11db);
  analogSetPinAttenuation(PIN_FINAL, ADC_11db);

  delay(500);

  // Medir el centro real de D34 para iniciar el notch sin un gran transitorio.
  long sumaInicial = 0;
  for (int i = 0; i < 50; i++) {
    sumaInicial += analogReadMilliVolts(PIN_ENTRADA);
    delay(5);
  }
  float x0 = (sumaInicial / 50.0f) / 1000.0f;

  z1_1 = (1.0f - b0) * x0;
  z2_1 = (b2 - a2) * x0;
  z1_2 = (1.0f - b0) * x0;
  z2_2 = (b2 - a2) * x0;

  dacWrite(PIN_DAC, 128);
  dacActual = 128;

  // Inicializar el promedio de 250 ms con el nivel real de D35 para evitar
  // que la senal arranque artificialmente desde cero.
  int inicialFinal = analogReadMilliVolts(PIN_FINAL);
  finalInstantaneo_mV = inicialFinal;
  finalSostenido_mV = inicialFinal;
  sumaFinal = 0;
  for (int i = 0; i < N_SOSTENIDO; i++) {
    bufferFinal[i] = inicialFinal;
    sumaFinal += inicialFinal;
  }

  // WiFi propio del ESP32.
  WiFi.mode(WIFI_AP);
  WiFi.softAP(WIFI_SSID, WIFI_PASS);

  server.on("/", HTTP_GET, handleRoot);
  server.on("/datos", HTTP_GET, handleDatos);
  server.on("/datos", HTTP_OPTIONS, handleOptions);
  server.onNotFound([]() {
    addCors();
    server.send(404, "text/plain", "No encontrado");
  });
  server.begin();

  Serial.println();
  Serial.println("EMG Rehab ESP32 iniciado");
  Serial.print("Red WiFi: ");
  Serial.println(WIFI_SSID);
  Serial.print("IP: ");
  Serial.println(WiFi.softAPIP());

  tAnterior = micros();
  nextTelemetryUs = tAnterior + TELEMETRY_PERIOD_US;
}

// =====================================================
// Loop
// =====================================================
void loop() {
  server.handleClient();

  if ((uint32_t)(micros() - tAnterior) >= TS_US) {
    tAnterior += TS_US;

    // 1) D34: band-pass + offset.
    int entrada_mV = analogReadMilliVolts(PIN_ENTRADA);
    float x = entrada_mV / 1000.0f;

    // 2) Notch 60 Hz x2. El offset se conserva.
    float y1 = notch60(x, z1_1, z2_1);
    float y2 = notch60(y1, z1_2, z2_2);

    if (y2 < 0.0f) y2 = 0.0f;
    if (y2 > 3.3f) y2 = 3.3f;

    int notch_mV = (int)(y2 * 1000.0f);

    // 3) DAC D25 -> restador analogico.
    int dac = (int)round((y2 / 3.3f) * 255.0f);
    if (dac < 0) dac = 0;
    if (dac > 255) dac = 255;
    dacWrite(PIN_DAC, dac);
    dacActual = dac;

    // 4) D35: salida final positiva del circuito.
    int final_mV = analogReadMilliVolts(PIN_FINAL);
    finalInstantaneo_mV = final_mV;

    // 5) Promedio movil de 250 ms.
    sumaFinal -= bufferFinal[indiceFinal];
    bufferFinal[indiceFinal] = final_mV;
    sumaFinal += final_mV;
    indiceFinal++;
    if (indiceFinal >= N_SOSTENIDO) indiceFinal = 0;
    finalSostenido_mV = (int)(sumaFinal / N_SOSTENIDO);

    const uint32_t nowUs = micros();
    if ((int32_t)(nowUs - nextTelemetryUs) >= 0) {
      nextTelemetryUs += TELEMETRY_PERIOD_US;
      if (telemetryCount >= TELEMETRY_CAPACITY) {
        telemetryTail = (telemetryTail + 1) % TELEMETRY_CAPACITY;
        telemetryCount--;
        telemetryDropped++;
      }
      telemetry[telemetryHead] = { millis(), finalSostenido_mV };
      telemetryHead = (telemetryHead + 1) % TELEMETRY_CAPACITY;
      telemetryCount++;
    }

    // 6) Diagnostico cada 200 ms.
    if (entrada_mV < d34Min) d34Min = entrada_mV;
    if (entrada_mV > d34Max) d34Max = entrada_mV;
    if (notch_mV < notchMin) notchMin = notch_mV;
    if (notch_mV > notchMax) notchMax = notch_mV;

    diagCount++;
    if (diagCount >= N_DIAG) {
      d34Vpp_mV = d34Max - d34Min;
      notchVpp_mV = notchMax - notchMin;
      diagCount = 0;
      d34Min = 10000;
      d34Max = 0;
      notchMin = 10000;
      notchMax = 0;
    }
  }
}
